<?php
/**
 * @file elc-h5p-ajax.php
 * Created by michaeldajewski on 7/04/19.
 */

/**
 * Helper function to get from xapi the content id - if defined.
 *
 * @param  array $data xapi passed from H5P event
 * @return int|void    content id
 */
function elc_get_content_id ( array $data ) {
	return $data['object']['definition']['extensions']['http://h5p.org/x-api/h5p-local-content-id'];
}

/**
 * Helper function to get from xapi passing percentage - if defined.
 *
 * @param  int $content_id content id
 * @return int|null    passing percentage
 */
function elc_h5p_passing_percent ( $content_id ) {
	$H5PP = H5P_Plugin::get_instance();
	$content = $H5PP->get_content( $content_id );
	if ( is_string( $content ) ) {
		// $H5PP->get_content() error: 'missing H5P identifier' or 'no H5P content with id'.
		return null;
	} else {
		$settings = $H5PP->get_content_settings( $content );
		$safe_parameters = json_decode( $settings['jsonContent'], true );
		$percentagePassing = $safe_parameters['behaviour']['percentagePassing']; // this one apeares only in Essay type
		$passPercentage = $safe_parameters['behaviour']['passPercentage'];
		return $passPercentage ? $passPercentage : $percentagePassing ? $percentagePassing : null;
	}
}

/**
 * Helper function.
 * Find in post content all h5p shortcodes and if they they have
 * corresponding 'elc_h5p_save_success_' meta_key.
 * If any of corresponding 'elc_h5p_save_success_' is 0 - meaning user failed,
 * return false. (Do not enable buttons).
 *
 * @param $post_id
 * @param $user_id
 * @return bool
 */
function elc_multiple_h5p_pass ( $post_id, $user_id ) {
	// Get post content.
	$post_content = get_post_field( 'post_content', $post_id, 'raw' );
	// Get shortcode arguments for H5P shortcodes.
	$shortcode_args['h5p'] = elc_get_shortcode_args( $post_content, array ( 'h5p' ) );
	// Get shortcode arguments for elc_h5p shortcodes.
	$shortcode_args['elc_h5p'] = elc_get_shortcode_args( $post_content, array ( 'elc_h5p' ) );

	$b_enable = true;

	foreach ($shortcode_args['h5p'] as $key => $value) {
		$content_id = $value['id'];
		$ignore = elc_h5p_ignore( $shortcode_args['elc_h5p'], $content_id );

		if ( ! $ignore ) {
			$settings = elc_get_h5p_content_settings( $content_id );
			if ( ! is_null( $settings ) ) {
				$lib_name = elc_get_h5p_library_name( $settings );
				// Chek if the library is on the white_list.
				if ( in_array( $lib_name, ELC_H5PLD_WHITE_LIST ) ) {
					// We process the h5p shortcode, otherwise we do nothing.
					$elc_h5p_save_success_meta = (bool)get_user_meta( $user_id, 'elc_h5p_save_success_' . $content_id, true );
					$b_enable = $b_enable && $elc_h5p_save_success_meta;
					if ( ! $b_enable ) break;
				}
			}
		}
	}

	return $b_enable;
}

/**
 * AJAX callback function.
 * The function saves to user_meta intermittent and/or completion results.
 * Than it sends back AJAX success.
 * Only data necessary to update UI.
 *
 * @SEE: assets/js/elc-h5p-ld.js elcSendAJAX
 * Events are filtered by elcHandleXAPI in order to minimize number of AJAX calls.
 * Process only events where result.completion is true.
 */
function elc_insert_data () {

	check_ajax_referer( 'elc_insert_data', 'nonce' );

	global $wp_query;
	global $pagenow;
	$postid = $wp_query->post->ID;

	// xapi contains event.data.statement - relevant data.
	$xapi = $_REQUEST['xapi'];
	$data = json_decode( stripslashes( $xapi ), true );

	// Save to user_meta elc_h5p_save_* keys.
	$user_id = get_current_user_id();

	// @SEE: wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api-event.js
	// H5P.XAPIEvent.prototype.setObject
	// There is no getContentId function but above explains statement below.
	$content_id = elc_get_content_id( $data );

	// Get post id.
	$url = wp_get_referer();
	$post_id = url_to_postid( $url );
	$post_content = get_post_field( 'post_content', $post_id, 'raw' );

	// Check if post has elc_h5p shortcode
	$shortcode_args['elc_h5p'] = elc_get_shortcode_args( $post_content, array ( 'elc_h5p' ) );

	// If there is elc_h5p shortcode with matching id and has ignore parameter we do nothing.
	$ignore = elc_h5p_ignore( $shortcode_args['elc_h5p'], $content_id );

	if ( $ignore ) {
		wp_die();
	}

	// Set 'elc_h5p_save_success_' to 0 untill we decide if user passed or not.
	// This meta key has to be set in order for us to cleanup history
	// in 'wp_h5p_contents_user_data' table.
	// @SEE: elc_learndash_delete_user_data()
	update_user_meta( $user_id, 'elc_h5p_save_success_' . $content_id, '0' );

	/**
	 * Filters data before it is used.
	 * @SEE: elc-h5p-learndash/assets/js/elc-h5p-ld.js
	 *       var elcSendAJAX.
	 *
	 * The return value is a $data param or empty array.
	 *
	 */
	$data = apply_filters( 'elc_h5p_filter_data', $data );

	if ( empty( $data ) ) {
		wp_die();
	}

	// If needed.
	// $subcontent_id = $data['object']['definition']['extensions']['http://h5p.org/x-api/h5p-subContentId'];

	// Get the verb correct way.
	// @SEE: wp-content/plugins/h5p/h5p-php-library/js/h5p-x-api-event.js
	// H5P.XAPIEvent.prototype.getVerb
	// Not used.
	// $verb_id = substr( $data['verb']['id'], 31 );


	// For 'InteractiveVideo' and 'CoursePresentation'
	// if there is a 'parent' (meaning this is one of interactions not result submission).
	// We could save the location on timeline
	// Format:
	//   'InteractiveVideo'   (string) e.g. "PT20S" stands for 20sec
	//   'CoursePresentation' (int)    e.g. 3 stands for 3rd slide
	//
	// context.extensions['http://id.tincanapi.com/extension/ending-point']
	// and there
	//   is:    object.definition.extensions['http://h5p.org/x-api/h5p-subContentId']
	// this event came while playing InteractiveVideo/CoursePresentation
	//   is NO: object.definition.extensions['http://h5p.org/x-api/h5p-subContentId']
	// we wait for the final submission where is NO 'parent'
	//
	$result = $data['result'];

	// Write to database intermittent results
	update_user_meta( $user_id, 'elc_h5p_save_score_scaled_' . $content_id, $result['score']['scaled'] );
	update_user_meta( $user_id, 'elc_h5p_save_score_raw_' . $content_id, $result['score']['raw'] );

	/**
	 * JS syntax:
	 * object.b_subContentId
	 *    response.object.definition.extensions['http://h5p.org/x-api/h5p-subContentId']
	 * context.b_parent
	 *    response.context.contextActivities.parent
	 * context.b_ending-point
	 *    response.context.extensions
	 *    response.context.extensions['http://id.tincanapi.com/extension/ending-point']
	 */
	$b_subContentId = isset( $data['object']['definition']['extensions']['http://h5p.org/x-api/h5p-subContentId'] );
	// b_parent filtered in wp-content/plugins/elc-h5p-learndash/assets/js/elc-h5p-ld.js elcHandleXAPI
//	$b_parent = isset( $data['context']['contextActivities']['parent'] );
	$b_ending_point = isset( $data['context']['extensions']['http://id.tincanapi.com/extension/ending-point'] );

	//! $b_subContentId && ! $b_parent && ! $b_ending_point
	if ( ! $b_subContentId && ! $b_ending_point ) {
		// Get plugins settings from database.
		$options = get_option( 'elc_h5p_options' );

		// Below is unused but we may need it.
		// Returns h5p library name e.g.: InteractiveVideo or CoursePresentation.
		// May be useful if we need to increase granulity to decide what to do on
		// per library (h5p content name).
		// The string contains the library version which could be used,
		// should we keep backwards compatibility.
		//
		//	$lib = explode( '-', substr(
		//		$data['context']['contextActivities']['category'][0]['id'], 29
		//	) )[0];

		// Passing evaluation.
		// Compare score scaled with passing percentage
		// @TODO: Remove testing for passing percentage.
		// It is used only by Essay and it resolves passing internally by setting
		// $result['success']
		$passing_percentage = elc_h5p_passing_percent( $content_id );

		if ( isset( $passing_percentage ) ) {
			$passing_case_msg = 'percentagePassing';
			$pass = $result['score']['scaled'] >= $passing_percentage * .01;
		} elseif ( isset( $result['success'] ) ) {
			$passing_case_msg = 'result.success';
			$pass = $result['success'];
		} elseif ( isset( $result['score']['scaled'] ) ) {
			$passing_case_msg = 'result.score.scaled';
			$pass = $result['score']['scaled'] > 0; // This one is for Summary, Mark the Words,
			// Summary does not have retry button. And so if it fails, the user cannot correct the answers
			// and he will be locked forever with 'mark complete' button being disabled.
			// This apply in the case when the Summary is standalone.
			// @TODO: add condition for the Summary where as long as $result['completion'] is true the $pass is set to true.
			// It may be necessary to test for library name.
		} elseif ( isset( $result['score']['raw'] ) && isset( $result['score']['max'] ) &&
			$result['score']['raw'] === 0 && $result['score']['max'] === 0
		) {
			// This is the case for Branching Scenario when 'Scoring options' is set to:
			// 'No scoring',
			// or 'Dynamically calculate score from user answers' and there is no content that sets score,
			// or 'Statically set score for each end scenario' and 'default "End scenario" screen'
			// 'Score' is set to 0.
			//
			// The plugin must enable the 'Mark complete' button to avoid the loop where the button is diabled for
			// all possible interactions.
			//
			$passing_case_msg = 'NO result.score.scaled';
			$pass = true;
		} else {
			// How did we get here?
			// @TODO: decide what do we do with the $pass true or false.
			$passing_case_msg = 'none';
			$pass = false;
		}

		// Save $pass to database
		update_user_meta( $user_id, 'elc_h5p_save_success_' . $content_id, $pass );

		// Set values for 'elcH5Presponse'.
		$msg_key = $pass ? 'succ_msg' : 'fail_msg';

		// @TODO: Check if 'mark_complete_button' and 'wpProQuiz_button' do appear on the same page.
		//        If not:
		//        Combine the two below to 'button_enable' => $pass
		//        and update ../assets/js/elc-h5p-ld.js accordingly.

		// If there are multiple h5p content in the same post we have to verify if all of them passed.
		$b_enable = elc_multiple_h5p_pass( $post_id, $user_id );

		// Build response data to send back.
		$response = array (
			'ldMarkCompleteButtonEnable' => $b_enable,
			'wpProQuizButtonEnable' => $b_enable,
			'h5pId' => 'h5pid-' . $content_id,
			'elcH5Presponse' => array (
				'text' => $options[$msg_key],
				'cssClass' => $msg_key,
			),
		);

		// Send JSON success.
		//
		wp_send_json_success( $response );
	} else {
		wp_die();
	}
}

/**
 * Register Ajax callback function(s).
 */
add_action( 'wp_ajax_nopriv_elc_insert_data', 'elc_insert_data' );
add_action( 'wp_ajax_elc_insert_data', 'elc_insert_data' );
