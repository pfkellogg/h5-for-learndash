/**
 * @file elc-h5p-ld.js
 * Created by michaeldajewski on 7/04/19.
 */

var H5P = H5P || {};

(function ($) {
    'use strict';

    var elcSendAJAX = function (elcAJAX, xapi) {
        $.ajax({
            url: elcAJAX.url,
            type: 'post',
            data: {
                action: 'elc_insert_data',
                nonce: elcAJAX.nonce,
                xapi: JSON.stringify(xapi)
            },
            success: function (response) {
                if (response) {
                    if (response.data) {
                        var data = response.data;
                        if (parseInt(elcAJAX.elc_debug)) console.log(data);

                        var learndash_mark_complete_button = $('.learndash_mark_complete_button');
                        if (learndash_mark_complete_button.length) {
                            learndash_mark_complete_button.prop('disabled', !data.ldMarkCompleteButtonEnable);
                        }

                        var startQuiz = $('.wpProQuiz_button[name=startQuiz]');
                        if (startQuiz.length) {
                            startQuiz.prop('disabled', !data.wpProQuizButtonEnable);
                        }

                        var elcH5PResponse = $('.elc-h5p-response.' + data.h5pId);
                        if (elcH5PResponse.length) {
                            var classList = elcH5PResponse.attr('class').split(/\s+/);
                            // Compare elcH5PResponse.selector with classList
                            // if class in the classList is not in selector,
                            // replace it with data.elcH5Presponse.cssClass
                            $.each(classList, function (key, className) {
                                if (elcH5PResponse.selector.indexOf(className) < 0) {
                                    // Replace value with data.elcH5Presponse.cssClass
                                    elcH5PResponse.removeClass(className).addClass(data.elcH5Presponse.cssClass);
                                    return false;
                                }
                            });
                            elcH5PResponse[0].innerHTML = data.elcH5Presponse.text;
                        }
                    }
                }
            },
            error: function () {
                // Here we can return any errors from
                // action: 'elc_insert_data'
                // passed through response.data
                //
                var errorMessage = 'response undefined ';
                console.log('elcSendAJAX() error: ' + errorMessage);
            }
        });
    };

    /**
     * Handle xAPI statements.
     * Filter out events before they are processed.
     *
     * @param {Object} event - Event.
     */
    var elcHandleXAPI = function (event) {
        var response = event.data.statement;
        if (typeof(response.result) !== 'undefined') {

            // @TODO: Look at
            // https://github.com/h5p/h5p-interactive-video/blob/master/src/scripts/endscreen.js
            // or
            // https://github.com/h5p/h5p-interactive-video/blob/1.20.2/src/scripts/endscreen.js
            // handleSubmit() function it triggers xAPIEvent

            // Filter out events and send AJAX
            var result = response.result;
            if (result.completion) {
                var b_parent = typeof(response.context.contextActivities.parent) !== 'undefined' ? true : false;
                // Send AJAX, update DB and update UI on response
                if (!b_parent) {
                    if (parseInt(elcAJAX.elc_debug)) console.log(response);
                    elcSendAJAX(elcAJAX, response);
                }
            }
        }

    };

    /**
     * Add xAPI event listener
     */
    document.onreadystatechange = function (e) {
        try {
            if (document.readyState == 'complete') {
                if (typeof(H5P.externalDispatcher) !== 'undefined') {
                    // Fix H5P iframe size for Learndash Quiz Questions.
                    let target = document.querySelector('.wpProQuiz_listItem');
                    if (target !== null) {
                        var observer = new MutationObserver(function(mutations) {
                            window.dispatchEvent(new Event('resize'));
                        });
                        observer.observe(target, {
                            attributes: true
                        });
                    }
                    // Dispatch H5P event.
                    H5P.externalDispatcher.on('xAPI', elcHandleXAPI);
                } else {
                    return;
                }
            }
        } catch (error) {
            console.log(error);
        }
    };

})(jQuery);
