<?php
/**
 * @file white-list.php
 * Created by michaeldajewski on 8/12/19.
 */

/**
 * Declare white-list.
 */
define( 'ELC_H5PLD_WHITE_LIST', array (
	'AdvancedBlanks',
	'ArithmeticQuiz',
	'BranchingScenario',
	'CoursePresentation',
	'DragQuestion',
	'DragText',
	'Essay',
	'Blanks',
	'ImageMultipleHotspotQuestion',
	'ImageHotspotQuestion',
	'FindTheWords',
	'Flashcards',
	'InteractiveVideo',
	'ImagePair',
	'ImageSequencing',
	'MarkTheWords',
	'MemoryGame',
	'MultiChoice',
	'QuestionSet',
	'SingleChoiceSet',
	'Summary',
	'TrueFalse',
) );
